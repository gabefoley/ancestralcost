"""

Ancestral Cost 

"""

__version__ = "1.0.6"


from ancestralcost.__main__ import ac_parser
